/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()
{
    int a,b;
    float add,sub,mul,mod,div;
    printf("\n enter the two numbers a and b resoectively:");
    scanf("%d%d",&a,&b);
    
    add= a+b;
     printf("\n addtion of a and b is:%f",add);
    sub= a-b;
    printf("\n sub of a and b is :%f",sub);
    
    div= a/b;
    printf("\n div of a and b is :%f",div);
    
    mul= a*b;
    printf("\nmul of a and b is:%f",mul);
    
    mod= a%b;
    printf("\n modulus of a and b is:%f",mod);
    
    return 0;
}
